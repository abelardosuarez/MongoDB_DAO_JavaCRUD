package teachers;

public interface ITeacher extends IId,IPerson {

}
