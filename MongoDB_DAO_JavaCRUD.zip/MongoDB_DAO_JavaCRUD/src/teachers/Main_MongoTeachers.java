package teachers;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.stream.MalformedJsonException;

public class Main_MongoTeachers {
	
	public static void printResult(MongoDAO collection,boolean print,Boolean result, String message, Teacher teacher) {
		if (result) {
			System.out.println(message + " OK " +teacher); 
		}
		else {
			System.out.println(message + " Error " +teacher); 
		}
		if (print) collection.printCollection();
	}
	
	public static void main(String[] args) throws MalformedJsonException {
		// TODO Auto-generated method stub
		
		MongoDAO collection = new MongoDAO("mongodb://localhost","faculty","teachers");
//		MongoDAO collection = new MongoDAO("mongodb+srv://user:password@cluster0-p4lmg.mongodb.net/","db","collection");

		final boolean print=true;
		final boolean noPrint= false;

		collection.drop();
		
		List< Teacher> teachers = new ArrayList<Teacher>();		
		teachers.add(new Teacher(new Person("Jesus","21544454")));
		teachers.add( new Teacher(new Person("Mary", "31254555")));
		teachers.add( new Teacher(new Person("Joseph","45667312")));

		boolean result;
		System.out.println("(01) for(Teacher teacher : teachers)");
		for(Teacher teacher : teachers) {
			result = collection.insert(teacher);
			printResult(collection,noPrint,result,"(01) insert new id = collection.insert(teacher)",teacher);
		}
		
		System.out.println("(02) collection.printCollection() ");
		collection.printCollection();
		
		System.out.println("(03) teachers = collection.get()");
		teachers = collection.get();
		for (Teacher teacher : teachers) {
			System.out.println("(03) = "+teacher);
		} 
		
		System.out.println("(04) teachers.get(0).setName(\"Jesus of Nazareth\")");
		teachers.get(0).setName("Jesus of Nazareth");
		result = collection.update(teachers.get(0)); 
		printResult(collection,print,result,"(04) update new name = collection.update(teachers.get(0))",teachers.get(0));
		
		System.out.println("(05) teachers.get(0).set_id(\"5e452c764f89bc1f11474636\")");
		teachers.get(0).set_id("5e452c764f89bc1f11474636");
		result = collection.update(teachers.get(0)); 
		printResult(collection,print,result,"(05) update new id = collection.update(teachers.get(0))",teachers.get(0));

		result = collection.insert(teachers.get(0));
		printResult(collection,print,result,"(06) insert new id = collection.insert(teachers.get(0))",teachers.get(0));
		
		result = collection.update(teachers.get(0)); 
		printResult(collection,print,result,"(07) update without change = collection.update(teachers.get(0))",teachers.get(0));
		
		result = collection.insert(teachers.get(0));
		printResult(collection,print,result,"(08) insert old id = collection.insert(teachers.get(0))",teachers.get(0));

		result = collection.delete(teachers.get(0)); 
		printResult(collection,print,result,"(09) delete old id = collection.delete(teachers.get(0))",teachers.get(0));

		result = collection.delete(teachers.get(0)); 
		printResult(collection,print,result,"(10) delete new id = collection.delete(teachers.get(0))",teachers.get(0));

	    System.out.println("(11) collection.getById("+teachers.get(2).get_id()+")="+collection.getById(teachers.get(2).get_id()));

	}
}
