package teachers;

public interface IId {
	
	public String get_id();
	
	public void set_id(String id);

}
