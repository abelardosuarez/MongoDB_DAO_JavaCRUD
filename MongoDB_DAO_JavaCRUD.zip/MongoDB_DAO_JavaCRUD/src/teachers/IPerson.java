package teachers;

public interface IPerson {
	
	public String getName();

	public void setName(String name);

	public String getDni();

	public void setDni(String dni);
}
